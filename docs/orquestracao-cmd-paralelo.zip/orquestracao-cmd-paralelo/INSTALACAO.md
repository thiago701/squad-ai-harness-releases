# Como instalar

Requisitos: Windows 10/11, Python 3.9+, git, e pelo menos um CLI de agente instalado e logado. Windows Terminal é recomendado (abas); sem ele, o script usa janelas minimizadas.

## Opção A: skill independente

Copie a pasta `orquestracao-cmd-paralelo/` inteira para onde as suas skills vivem:

- GitHub Copilot no VS Code: `.github/skills/orquestracao-cmd-paralelo/` (projeto) ou `~/.copilot/skills/` (pessoal)
- Claude Code: `.claude/skills/` ou `~/.claude/skills/`
- Repositório da Squad AI: `skills/orquestracao-cmd-paralelo/` (fonte), deixando a sincronização gerar o resto

## Opção B: sub-skill de uma skill existente (ex.: squad-pipeline)

1. Copie `references/orquestracao-cmd-paralelo.md` para o `references/` da skill hospedeira.
2. Copie `scripts/orquestrador_cmd.py` e `scripts/orq.cmd` para o `scripts/` dela.
3. Acrescente esta linha à tabela de referências do `SKILL.md` hospedeiro:

```
| [`references/orquestracao-cmd-paralelo.md`](references/orquestracao-cmd-paralelo.md) | Executar as tarefas de `specs/<feature>/tasks.md` em paralelo com vários CLIs de agente em terminais CMD no Windows (abas por agente, circuit breaker e failover, decisões, delegação, revisão cruzada, consolidado e feedback). Só depois do GATE 1. |
```

O `SKILL.md` deste pacote não é necessário nessa opção.

## Opção C: prompt pronto para o Copilot

Copie `assets/copilot-orquestrador-cmd.prompt.md` para `.github/prompts/` e ajuste o caminho da skill dentro dele.

## Primeiro uso

```
python scripts\orquestrador_cmd.py diagnostico
python scripts\orquestrador_cmd.py autoteste
python scripts\orquestrador_cmd.py config-exemplo --saida orq.config.json     (opcional: para ajustar agentes e limites)
```

Para um primeiro teste com agentes de verdade, copie `assets/exemplo-spec/001-saudacao/` para `specs/` de um repositório de rascunho e rode `executar --spec specs/001-saudacao`. São quatro tarefas pequenas.
