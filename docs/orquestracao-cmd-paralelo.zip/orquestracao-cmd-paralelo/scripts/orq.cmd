@echo off
rem Atalho: orq <comando> ...   (ex.: orq status)
setlocal
where python >nul 2>nul
if %errorlevel%==0 (
  python "%~dp0orquestrador_cmd.py" %*
) else (
  py -3 "%~dp0orquestrador_cmd.py" %*
)
exit /b %errorlevel%
