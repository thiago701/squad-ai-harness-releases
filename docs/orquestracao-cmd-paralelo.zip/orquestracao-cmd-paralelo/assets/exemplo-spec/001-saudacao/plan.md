# Plano técnico

- Python 3.9+, só biblioteca padrão; testes com `unittest`.
- `saudacao/nucleo.py`: função `saudar(nome, idioma="pt")`.
- `saudacao/__main__.py`: CLI com `argparse`.
- `tests/`: um arquivo de teste por módulo.
- Comando de verificação: `python -m unittest discover -s tests`.
