# Tarefas: utilitário de saudação

## Fase 1: Fundação
- [ ] T001 Criar o pacote `saudacao/` e a pasta `tests/` com um teste mínimo passando

## Fase 2: Núcleo e CLI
- [ ] T002 [P] Implementar `saudar()` em `saudacao/nucleo.py` com testes para CA1, CA2 e CA3 (tema: núcleo)
- [ ] T003 [P] Implementar a CLI em `saudacao/__main__.py` com teste para CA4 (tema: cli)
      A CLI importa `saudar` de `saudacao.nucleo`; se ela ainda não existir no seu worktree, crie o teste e a CLI
      contra a assinatura definida no plano.

## Fase 3: Fechamento
- [ ] T004 Escrever o README com exemplos de uso e rodar a suíte completa
