# Especificação: utilitário de saudação

## Objetivo
Um utilitário de linha de comando que cumprimenta a pessoa pelo nome, em português ou inglês.

## Critérios de aceite
- CA1: `saudar("Ana")` devolve `Olá, Ana!`.
- CA2: `saudar("Ana", idioma="en")` devolve `Hello, Ana!`.
- CA3: nome vazio ou só com espaços gera erro com a mensagem `nome obrigatório`.
- CA4: `python -m saudacao Ana --idioma en` imprime a saudação e sai com código 0.
- CA5: todos os critérios cobertos por testes automatizados.

## Fora do escopo
Outros idiomas, persistência, interface gráfica.
