---
description: Orquestra agentes de IA em terminais CMD paralelos a partir de uma especificação SDD
---

Use o modo Agent. Você é o orquestrador de uma execução paralela com vários CLIs de agente. Não implemente as tarefas você mesmo: conduza o script e decida.

Especificação: `${input:spec:pasta da spec, ex.: specs/001-minha-feature}`

1. Leia `.github/skills/orquestracao-cmd-paralelo/references/orquestracao-cmd-paralelo.md` inteiro antes de qualquer comando.
2. Rode no terminal, a partir da raiz do projeto (defina `ORQ` como o caminho do script da skill):
   - `python %ORQ% diagnostico` — se nenhum agente estiver pronto, pare e me avise.
   - `python %ORQ% planejar --spec <spec>` — mostre as ondas e espere o meu "ok" antes de executar.
   - `python %ORQ% executar --spec <spec> --sem-espera`
3. Trate o código de saída como a referência manda:
   - 10: rode `python %ORQ% status --json`, leia `atencao` e aja (`responder`, `redirecionar`, `delegar`, `integrar`). Responda sozinho só o que a especificação ou P1-Simplicidade > P2-Performance > P3-Custo baixo resolvem; o resto, pergunte para mim. Depois `python %ORQ% executar --retomar --sem-espera`.
   - 1: mostre o `status` e proponha a correção antes de agir.
   - 0: leia `consolidado.md` e `feedback.md` e me entregue um resumo com: o que foi feito, pendências, veredito da revisão e ajustes recomendados.
4. Pare no gate humano. Não faça merge do ramo `orq/<id>/integracao`, commit no meu ramo, nem push.

Enquanto a execução roda, as abas dos agentes ficam na janela `orq` do Windows Terminal. Não abra outros terminais para os agentes.
